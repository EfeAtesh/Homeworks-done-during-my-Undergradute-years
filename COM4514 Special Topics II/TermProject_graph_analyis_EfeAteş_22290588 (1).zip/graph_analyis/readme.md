Special Topics 2
Term Project

Student No: 22290588
Student Name: Efe ATEŞ



movie_graph_analysis/
│
├── maim.py
│
├── requirements.txt
│
└── readme.md
